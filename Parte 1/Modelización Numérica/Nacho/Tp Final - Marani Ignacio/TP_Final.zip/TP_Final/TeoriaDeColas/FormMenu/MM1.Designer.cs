﻿namespace Vista
{
    partial class MM1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtLambda = new TextBox();
            txtMu = new TextBox();
            label4 = new Label();
            label5 = new Label();
            cbTipoCalculo = new ComboBox();
            btnResetear = new Button();
            lblN = new Label();
            btnCalcular = new Button();
            txtN = new TextBox();
            label7 = new Label();
            lblResultado = new Label();
            panel1 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 7);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 0;
            label1.Text = "INGRESAR DATOS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 36);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 1;
            label2.Text = "Velocidad de llegada (λ):";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 64);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 2;
            label3.Text = "Velocidad de servicio (μ):";
            // 
            // txtLambda
            // 
            txtLambda.Location = new Point(184, 34);
            txtLambda.Margin = new Padding(3, 2, 3, 2);
            txtLambda.Name = "txtLambda";
            txtLambda.Size = new Size(62, 23);
            txtLambda.TabIndex = 3;
            // 
            // txtMu
            // 
            txtMu.Location = new Point(184, 62);
            txtMu.Margin = new Padding(3, 2, 3, 2);
            txtMu.Name = "txtMu";
            txtMu.Size = new Size(62, 23);
            txtMu.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label4.Location = new Point(250, 36);
            label4.Name = "label4";
            label4.Size = new Size(83, 15);
            label4.TabIndex = 5;
            label4.Text = "[clientes/hora]";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label5.Location = new Point(250, 64);
            label5.Name = "label5";
            label5.Size = new Size(83, 15);
            label5.TabIndex = 6;
            label5.Text = "[clientes/hora]";
            // 
            // cbTipoCalculo
            // 
            cbTipoCalculo.FormattingEnabled = true;
            cbTipoCalculo.Location = new Point(29, 100);
            cbTipoCalculo.Margin = new Padding(3, 2, 3, 2);
            cbTipoCalculo.Name = "cbTipoCalculo";
            cbTipoCalculo.Size = new Size(415, 23);
            cbTipoCalculo.TabIndex = 8;
            cbTipoCalculo.SelectedIndexChanged += cbTipoCalculo_SelectedIndexChanged;
            // 
            // btnResetear
            // 
            btnResetear.BackColor = Color.Gold;
            btnResetear.Location = new Point(467, 7);
            btnResetear.Margin = new Padding(3, 2, 3, 2);
            btnResetear.Name = "btnResetear";
            btnResetear.Size = new Size(82, 22);
            btnResetear.TabIndex = 12;
            btnResetear.Text = "Resetear";
            btnResetear.TextImageRelation = TextImageRelation.TextAboveImage;
            btnResetear.UseVisualStyleBackColor = false;
            btnResetear.Click += btnResetear_Click;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Location = new Point(382, 128);
            lblN.Name = "lblN";
            lblN.Size = new Size(25, 15);
            lblN.TabIndex = 9;
            lblN.Text = "n =";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(467, 100);
            btnCalcular.Margin = new Padding(3, 2, 3, 2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(82, 22);
            btnCalcular.TabIndex = 7;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtN
            // 
            txtN.Location = new Point(415, 126);
            txtN.Margin = new Padding(3, 2, 3, 2);
            txtN.Name = "txtN";
            txtN.Size = new Size(29, 23);
            txtN.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 8);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 0;
            label7.Text = "Resultado:";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(10, 34);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(51, 15);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Solution";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SpringGreen;
            panel1.Controls.Add(lblResultado);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 161);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(560, 98);
            panel1.TabIndex = 11;
            // 
            // MM1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(560, 259);
            Controls.Add(btnResetear);
            Controls.Add(panel1);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Controls.Add(cbTipoCalculo);
            Controls.Add(btnCalcular);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtMu);
            Controls.Add(txtLambda);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MinimizeBox = false;
            Name = "MM1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MM1";
            FormClosing += MM1_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtLambda;
        private TextBox txtMu;
        private Label label4;
        private Label label5;
        private ComboBox cbTipoCalculo;
        private Button btnResetear;
        private Label lblN;
        private Button btnCalcular;
        private TextBox txtN;
        private Label label7;
        private Label lblResultado;
        private Panel panel1;
    }
}