﻿using FormMenu;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtendedNumerics;

namespace Vista
{
    public partial class MM1N : Form
    {
        public MM1N()
        {
            InitializeComponent();
            cbTipoCalculo.Items.Clear();
            cbTipoCalculo.Items.Add("Factor de uso (P)");
            cbTipoCalculo.Items.Add("Probabilidad de bloqueo (Pb)");
            cbTipoCalculo.Items.Add("Tasa de rechazo (ζ)");
            cbTipoCalculo.Items.Add("Tasa de llegada efectiva (/λ)");
            cbTipoCalculo.Items.Add("Utilización efectiva del sistema (/P)");
            cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
            cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
            cbTipoCalculo.Items.Add("Tiempo promedio de permanencia en el sistema (Ws)");
            cbTipoCalculo.Items.Add("Tiempo efectivo en el sistema (/Ws)");
            cbTipoCalculo.Items.Add("Tiempo de espera en cola (Wq)");
            cbTipoCalculo.Items.Add("Número promedio de clientes en cola para un sistema ocupado (Lb)");
            cbTipoCalculo.Items.Add("Tiempo promedio de clientes en cola para un sistema ocupado (Wb)");
            cbTipoCalculo.Items.Add("Número promedio de clientes en el sistema (Ls)");
            cbTipoCalculo.Items.Add("Número promedio de clientes en la cola (Lq)");
            cbTipoCalculo.Items.Add("Rendimiento de entrada (γi)");
            cbTipoCalculo.Items.Add("Rendimiento de salida (γo)");
            lblResultado.Text = string.Empty;
        }

        private void MM1N_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            var formMenu = new Menu();
            formMenu.ShowDialog();
        }

        public bool ValidarDatos()
        {       
            decimal lambda;
            if (!decimal.TryParse(txtLambda.Text, out lambda))
            {
                MessageBox.Show("Ingrese el λ correctamente");
                return false;
            }

            decimal mu;
            if (!decimal.TryParse(txtMu.Text, out mu))
            {
                MessageBox.Show("Ingrese el μ correctamente");
                return false;
            }

            int n;
            if (!int.TryParse(txtN.Text, out n))
            {
                MessageBox.Show("Ingrese el n correctamente");
                return false;
            }

            return true;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidarDatos())
                {
                    return;
                }
                BigDecimal lambda = BigDecimal.Parse(txtLambda.Text);
                BigDecimal mu = BigDecimal.Parse(txtMu.Text);
                int n = Convert.ToInt32(txtN.Text);

                if (cbTipoCalculo.Text == "Factor de uso (P)")
                {
                    BigDecimal resultado = lambda / mu;
                    resultado = BigDecimal.Round(resultado, 5);
                    lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                }

                if (cbTipoCalculo.Text == "Probabilidad de bloqueo (Pb)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La probabilidad de bloqueo (Pb) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal resultado = (clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de bloqueo (Pb) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }

                if (cbTipoCalculo.Text == "Tasa de rechazo (ζ)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La tasa de rechazo (ζ) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal resultado = lambda * ((clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema));
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "Tasa de rechazo (ζ) = " + resultado.ToString() + " [clientes / hora]";
                    }
                }

                if (cbTipoCalculo.Text == "Tasa de llegada efectiva (/λ)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La tasa de llegada efectiva (/λ) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal resultado = lambda * ((BigDecimal.One - (clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema)));
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "La tasa de llegada efectiva (/λ) = " + resultado.ToString() + " [clientes / hora]";
                    }
                }

                if (cbTipoCalculo.Text == "Utilización efectiva del sistema (/P)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La utilización efectiva del sistema (/P) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal resultado = (lambda * ((BigDecimal.One - (clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema)))) / mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "La utilización efectiva del sistema (/P) = " + resultado.ToString() + " [clientes / hora]";
                    }
                }

                if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal resultado = (((BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema));
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }

                if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }
                        BigDecimal Po = (((BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema));
                        BigDecimal resultado = clienteEnEspera * Po;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }

                if (cbTipoCalculo.Text == "Número promedio de clientes en el sistema (Ls)")
                {
                    BigDecimal P = lambda / mu;
                    if (P == BigDecimal.One)
                    {
                        BigDecimal resultado = n / 2;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El número promedio de clientes en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                    }
                    else
                    {
                        BigDecimal clienteEnSistema = BigDecimal.One;
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }
                        BigDecimal resultado = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El número promedio de clientes en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                    }
                }

                if (cbTipoCalculo.Text == "Número promedio de clientes en la cola (Lq)")
                {
                    BigDecimal P = lambda / mu;
                    if (P == BigDecimal.One)
                    {
                        BigDecimal resultado = (n * (n - 1)) / (2 * (n + 1));
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El número promedio de clientes en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                    }
                    else
                    {
                        BigDecimal clienteEnEspera = BigDecimal.One;
                        BigDecimal clienteEnSistema = BigDecimal.One;
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = Ls - (((BigDecimal.One - clienteEnEspera) * P)) / (BigDecimal.One - clienteEnSistema);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El número promedio de clientes en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                    }
                }

                if (cbTipoCalculo.Text == "Tiempo efectivo en el sistema (/Ws)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "El tiempo efectivo en el sistema (/Ws) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal lambdaEfec = lambda * ((BigDecimal.One - (clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema)));
                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = Ls / lambdaEfec;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo efectivo en el sistema (/Ws) = " + resultado.ToString() + " [horas]";
                    }
                }

                if (cbTipoCalculo.Text == "Tiempo promedio de permanencia en el sistema (Ws)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        BigDecimal Ls = n / 2;
                        BigDecimal resultado = Ls / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo promedio de permanencia en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = Ls / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo promedio de permanencia en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                    }
                }

                if (cbTipoCalculo.Text == "Tiempo de espera en cola (Wq)")
                {
                    BigDecimal P = lambda / mu;
                    if (P == BigDecimal.One)
                    {
                        BigDecimal Lq = (n * (n - 1)) / (2 * (n + 1));
                        BigDecimal resultado = Lq / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo de espera en cola (Wq) = " + resultado.ToString() + " [horas]";
                    }
                    else
                    {
                        BigDecimal clienteEnEspera = BigDecimal.One;
                        BigDecimal clienteEnSistema = BigDecimal.One;
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Lq = Ls - (((BigDecimal.One - clienteEnEspera) * P)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = Lq / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo de espera en cola (Wq) = " + resultado.ToString() + " [horas]";
                    }
                }

                if (cbTipoCalculo.Text == "Número promedio de clientes en cola para un sistema ocupado (Lb)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "El número promedio de clientes en cola para un sistema ocupado (Lb) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Lq = Ls - (((BigDecimal.One - clienteEnEspera) * P)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Po = (BigDecimal.One - P) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = Lq / (BigDecimal.One - Po);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El número promedio de clientes en cola para un sistema ocupado (Lb) = " + resultado.ToString() + " [clientes]";
                    }
                }

                if (cbTipoCalculo.Text == "Tiempo promedio de clientes en cola para un sistema ocupado (Wb)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "El tiempo promedio de clientes en cola para un sistema ocupado (Wb) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Ls = (P / (BigDecimal.One - P)) - (((n + 1) * clienteEnSistema)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Lq = Ls - (((BigDecimal.One - clienteEnEspera) * P)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Po = (BigDecimal.One - P) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal Wq = Lq / lambda;
                        BigDecimal resultado = Wq / (BigDecimal.One - Po);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo promedio de clientes en cola para un sistema ocupado (Wb) = " + resultado.ToString() + " [horas]";
                    }
                }

                if (cbTipoCalculo.Text == "Rendimiento de entrada (γi)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnEspera = BigDecimal.One;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "El rendimiento de entrada (γi) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n; i++)
                        {
                            clienteEnEspera *= P;
                        }
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Pb = (clienteEnEspera * (BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema);
                        BigDecimal resultado = lambda - (lambda * Pb);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El rendimiento de entrada (γi) = " + resultado.ToString();
                    }
                }

                if (cbTipoCalculo.Text == "Rendimiento de salida (γo)")
                {
                    BigDecimal P = lambda / mu;
                    BigDecimal clienteEnSistema = BigDecimal.One;
                    if (P == BigDecimal.One)
                    {
                        lblResultado.Text = "El rendimiento de salida (γo) = ∄";
                    }
                    else
                    {
                        for (int i = 0; i < n + 1; i++)
                        {
                            clienteEnSistema *= P;
                        }

                        BigDecimal Po = (((BigDecimal.One - P)) / (BigDecimal.One - clienteEnSistema));
                        BigDecimal resultado = mu - (mu * Po);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El rendimiento de salida (γo) = " + resultado.ToString();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error en la introducción de datos");
            }
        }

        private void btnResetear_Click(object sender, EventArgs e)
        {
            txtLambda.Text = string.Empty;
            txtMu.Text = string.Empty;
            txtN.Text = string.Empty;
            lblResultado.Text = string.Empty;
        }
    }
}
