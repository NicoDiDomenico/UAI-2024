﻿using ExtendedNumerics;
using FormMenu;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class MM1_Especiales : Form
    {
        public MM1_Especiales()
        {
            InitializeComponent();
            cbTipoCalculo.Items.Clear();
            cbTipoCalculo.Items.Add("Factor de uso (P)");
            cbTipoCalculo.Items.Add("Tiempo entre llegada (1/λ)");
            cbTipoCalculo.Items.Add("Tiempo entre servicio (1/μ)");
            cbTipoCalculo.Items.Add("Cantidad de unidades en el sistema (Ls)");
            cbTipoCalculo.Items.Add("Cantidad de unidades en la cola (Lq)");
            cbTipoCalculo.Items.Add("Tiempo en el sistema (Ws)");
            cbTipoCalculo.Items.Add("Tiempo en la cola (Wq)");
            cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
            cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
            cbTipoCalculo.Items.Add("Probabilidad de al menos n unidades en el sistema (Pan)");
            cbTipoCalculo.Items.Add("Probabilidad de a lo sumo n unidades en el sistema (Psn)");
            cbTipoMM1.Items.Clear();
            cbTipoMM1.Items.Add("Unión de Tráfico");
            cbTipoMM1.Items.Add("Partición de Tráfico");
            lblResultado.Text = string.Empty;
            lblN.Visible = false;
            txtN.Visible = false;
            lblCiclos.Visible = false;
            lbllambda2.Visible = false;
            txtCiclos.Visible = false;
            txtLambda2.Visible = false;
            lbl_cli_hor.Visible = false;
        }

        private void cbTipoMM1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTipoMM1.Text == "Unión de Tráfico")
            {
                lbllambda1.Text = "Velocidad de llegada (λ1):";
                lblCiclos.Visible = false;
                lbllambda2.Visible = true;
                txtCiclos.Visible = false;
                txtLambda2.Visible = true;
                lbl_cli_hor.Visible = true;
                cbTipoCalculo.Items.Clear();
                cbTipoCalculo.Items.Add("Factor de uso (P)");
                cbTipoCalculo.Items.Add("Tiempo entre llegada (1/λ)");
                cbTipoCalculo.Items.Add("Tiempo entre servicio (1/μ)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en el sistema (Ls)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en la cola (Lq)");
                cbTipoCalculo.Items.Add("Tiempo en el sistema (Ws)");
                cbTipoCalculo.Items.Add("Tiempo en la cola (Wq)");
                cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
                cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
                cbTipoCalculo.Items.Add("Probabilidad de al menos n unidades en el sistema (Pan)");
                cbTipoCalculo.Items.Add("Probabilidad de a lo sumo n unidades en el sistema (Psn)");
            }
            if (cbTipoMM1.Text == "Partición de Tráfico")
            {
                lbllambda1.Text = "Velocidad de llegada (λ):";
                lblCiclos.Visible = false;
                lbllambda2.Visible = false;
                txtCiclos.Visible = false;
                txtLambda2.Visible = false;
                lbl_cli_hor.Visible = false;
                cbTipoCalculo.Items.Clear();
                cbTipoCalculo.Items.Add("Factor de uso (P)");
                cbTipoCalculo.Items.Add("Tiempo entre llegada (1/λ)");
                cbTipoCalculo.Items.Add("Tiempo entre servicio (1/μ)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en el sistema (Ls)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en la cola (Lq)");
                cbTipoCalculo.Items.Add("Tiempo en el sistema (Ws)");
                cbTipoCalculo.Items.Add("Tiempo en la cola (Wq)");
                cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
                cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
                cbTipoCalculo.Items.Add("Probabilidad de al menos n unidades en el sistema (Pan)");
                cbTipoCalculo.Items.Add("Probabilidad de a lo sumo n unidades en el sistema (Psn)");
                cbTipoCalculo.Items.Add("Probabilidad de que tome el camino A");
                cbTipoCalculo.Items.Add("Probabilidad de que tome el camino B");
            }
        }

        private void MM1_Especiales_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            var formMenu = new Menu();
            formMenu.ShowDialog();
        }

        private void cbTipoCalculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)" || cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)" || cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
            {
                lblN.Visible = true;
                txtN.Visible = true;
            }
            else
            {
                lblN.Visible = false;
                txtN.Visible = false;
            }
        }

        public bool ValidarDatos()
        {
            decimal lambda1;
            if (!decimal.TryParse(txtLambda.Text, out lambda1))
            {
                MessageBox.Show("Ingrese el λ correctamente");
                return false;
            }

            decimal mu;
            if (!decimal.TryParse(txtMu.Text, out mu))
            {
                MessageBox.Show("Ingrese el μ correctamente");
                return false;
            }

            return true;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidarDatos())
                {
                    return;
                }

                if (cbTipoMM1.Text == "Unión de Tráfico")
                {
                    decimal lambdaCheck;
                    if (!decimal.TryParse(txtLambda.Text, out lambdaCheck))
                    {
                        MessageBox.Show("Ingrese el λ correctamente");
                        return;
                    }

                    BigDecimal lambda1 = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal lambda2 = BigDecimal.Parse(txtLambda2.Text);
                    BigDecimal lambda = lambda1 + lambda2;
                    BigDecimal mu = BigDecimal.Parse(txtMu.Text);
                    int n;

                    if (cbTipoCalculo.Text == "Factor de uso (P)")
                    {
                        BigDecimal resultado = lambda / mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre llegada (1/λ)")
                    {
                        BigDecimal resultado = BigDecimal.One / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre llegada (1/λ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre servicio (1/μ)")
                    {
                        BigDecimal resultado = BigDecimal.One / mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre servicio (1/μ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en el sistema (Ls)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = lambda / (mu - lambda);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en la cola (Lq)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = (lambda * lambda) / (mu * (mu - lambda));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en el sistema (Ws)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "El tiempo en el sistema (Ws) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = BigDecimal.One / (mu - lambda);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en la cola (Wq)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "El tiempo en la cola (Wq) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = lambda / (mu * (mu - lambda));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en la cola (Wq) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                    {
                        BigDecimal resultado = BigDecimal.One - (lambda / mu);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                    {
                        if (lambda / mu == BigDecimal.One)
                        {
                            lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = 0 --> 0 %";
                        }
                        else
                        {
                            if (!int.TryParse(txtN.Text, out n))
                            {
                                MessageBox.Show("Ingrese el n correctamente");
                                return;
                            }
                            n = Convert.ToInt32(txtN.Text);
                            BigDecimal pParcial = lambda / mu;
                            BigDecimal pFinal = BigDecimal.One;
                            for (int i = 0; i < n; i++)
                            {
                                pFinal *= pParcial;
                            }
                            BigDecimal resultado = (BigDecimal.One - (lambda / mu)) * (pFinal);
                            BigDecimal resultadoPorcentual = resultado * 100;
                            resultado = BigDecimal.Round(resultado, 5);
                            resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                            lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / mu;
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal sumatoria = p0;

                        for (int i = 1; i < n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - pParcial) * pFinal;
                            sumatoria += pFinal;
                        }

                        BigDecimal resultado = BigDecimal.One - sumatoria;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de al menos n unidades en el sistema (Pan) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / mu;
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal resultado = p0;

                        for (int i = 1; i <= n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - pParcial) * pFinal;
                            resultado += pFinal;
                        }
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de a lo sumo n unidades en el sistema (Psn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }

                if (cbTipoMM1.Text == "Partición de Tráfico")
                {
                    BigDecimal lambda = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal mu = BigDecimal.Parse(txtMu.Text);
                    int n;

                    if (cbTipoCalculo.Text == "Factor de uso (P)")
                    {
                        BigDecimal resultado = lambda / mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de que tome el camino A")
                    {
                        BigDecimal resultado = (lambda / mu) * mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "La probabilidad de que tome el camino A = " + resultado.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de que tome el camino B")
                    {
                        BigDecimal resultado = (1 - (lambda / mu)) * mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "La probabilidad de que tome el camino B = " + resultado.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre llegada (1/λ)")
                    {
                        BigDecimal resultado = BigDecimal.One / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre llegada (1/λ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre servicio (1/μ)")
                    {
                        BigDecimal resultado = BigDecimal.One / mu;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre servicio (1/μ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en el sistema (Ls)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = lambda / (mu - lambda);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en la cola (Lq)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = (lambda * lambda) / (mu * (mu - lambda));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en el sistema (Ws)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "El tiempo en el sistema (Ws) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = BigDecimal.One / (mu - lambda);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en la cola (Wq)")
                    {
                        if (mu == lambda)
                        {
                            lblResultado.Text = "El tiempo en la cola (Wq) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = lambda / (mu * (mu - lambda));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en la cola (Wq) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                    {
                        BigDecimal resultado = BigDecimal.One - (lambda / mu);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                    {
                        if (lambda / mu == BigDecimal.One)
                        {
                            lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = 0 --> 0 %";
                        }
                        else
                        {
                            if (!int.TryParse(txtN.Text, out n))
                            {
                                MessageBox.Show("Ingrese el n correctamente");
                                return;
                            }
                            n = Convert.ToInt32(txtN.Text);
                            BigDecimal pParcial = lambda / mu;
                            BigDecimal pFinal = BigDecimal.One;
                            for (int i = 0; i < n; i++)
                            {
                                pFinal *= pParcial;
                            }
                            BigDecimal resultado = (BigDecimal.One - (lambda / mu)) * (pFinal);
                            BigDecimal resultadoPorcentual = resultado * 100;
                            resultado = BigDecimal.Round(resultado, 5);
                            resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                            lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / mu;
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal sumatoria = p0;

                        for (int i = 1; i < n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - pParcial) * pFinal;
                            sumatoria += pFinal;
                        }

                        BigDecimal resultado = BigDecimal.One - sumatoria;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de al menos n unidades en el sistema (Pan) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / mu;
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal resultado = p0;

                        for (int i = 1; i <= n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - pParcial) * pFinal;
                            resultado += pFinal;
                        }
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de a lo sumo n unidades en el sistema (Psn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error en la introducción de datos");
            }         
        }

        private void btnResetear_Click(object sender, EventArgs e)
        {
            txtLambda.Text = string.Empty;
            txtMu.Text = string.Empty;
            txtN.Text = string.Empty;
            txtLambda2.Text = string.Empty;
            txtCiclos.Text = string.Empty;
            lblResultado.Text = string.Empty;
        }
    }
}
