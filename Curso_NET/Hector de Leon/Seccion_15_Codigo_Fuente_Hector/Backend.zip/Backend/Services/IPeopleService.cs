﻿using Backend.Controllers;

namespace Backend.Services
{
    public interface IPeopleService
    {
        bool Validate(People people);
    }
}
