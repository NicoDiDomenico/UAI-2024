/*
**            Inspect_sysindexes.SQL
**
**  This script queries the sysindexes system table.
**  It joins to the sysobjects table to get the table names.
**  It selects only the user defined tables (those with 
**  an id greater than 100.)
*/

USE credit
GO

SELECT t.name AS [Table Name], i.name AS [Index Name], i.*
FROM sysobjects AS t JOIN sysindexes AS i ON t.id = i.id
WHERE t.id > 100
ORDER BY t.name
