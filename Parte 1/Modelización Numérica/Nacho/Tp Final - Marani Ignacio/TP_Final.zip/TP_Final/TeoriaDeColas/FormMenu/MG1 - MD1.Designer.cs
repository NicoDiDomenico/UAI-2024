﻿namespace Vista
{
    partial class MG1___MD1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnResetear = new Button();
            panel1 = new Panel();
            lblResultado = new Label();
            label7 = new Label();
            txtN = new TextBox();
            lblN = new Label();
            cbTipoCalculo = new ComboBox();
            btnCalcular = new Button();
            label5 = new Label();
            label4 = new Label();
            txtMu = new TextBox();
            txtLambda = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label6 = new Label();
            txtDesvio = new TextBox();
            lblDesvioEstandar = new Label();
            cbCuadrado = new CheckBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnResetear
            // 
            btnResetear.BackColor = Color.Gold;
            btnResetear.Location = new Point(467, 4);
            btnResetear.Margin = new Padding(3, 2, 3, 2);
            btnResetear.Name = "btnResetear";
            btnResetear.Size = new Size(82, 22);
            btnResetear.TabIndex = 25;
            btnResetear.Text = "Resetear";
            btnResetear.TextImageRelation = TextImageRelation.TextAboveImage;
            btnResetear.UseVisualStyleBackColor = false;
            btnResetear.Click += btnResetear_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SpringGreen;
            panel1.Controls.Add(lblResultado);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 194);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(560, 98);
            panel1.TabIndex = 24;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(10, 34);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(51, 15);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Solution";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 8);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 0;
            label7.Text = "Resultado:";
            // 
            // txtN
            // 
            txtN.Location = new Point(415, 154);
            txtN.Margin = new Padding(3, 2, 3, 2);
            txtN.Name = "txtN";
            txtN.Size = new Size(29, 23);
            txtN.TabIndex = 23;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Location = new Point(382, 156);
            lblN.Name = "lblN";
            lblN.Size = new Size(25, 15);
            lblN.TabIndex = 22;
            lblN.Text = "n =";
            // 
            // cbTipoCalculo
            // 
            cbTipoCalculo.FormattingEnabled = true;
            cbTipoCalculo.Location = new Point(29, 128);
            cbTipoCalculo.Margin = new Padding(3, 2, 3, 2);
            cbTipoCalculo.Name = "cbTipoCalculo";
            cbTipoCalculo.Size = new Size(415, 23);
            cbTipoCalculo.TabIndex = 21;
            cbTipoCalculo.SelectedIndexChanged += cbTipoCalculo_SelectedIndexChanged;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(467, 128);
            btnCalcular.Margin = new Padding(3, 2, 3, 2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(82, 22);
            btnCalcular.TabIndex = 20;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label5.Location = new Point(250, 61);
            label5.Name = "label5";
            label5.Size = new Size(83, 15);
            label5.TabIndex = 19;
            label5.Text = "[clientes/hora]";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label4.Location = new Point(250, 33);
            label4.Name = "label4";
            label4.Size = new Size(83, 15);
            label4.TabIndex = 18;
            label4.Text = "[clientes/hora]";
            // 
            // txtMu
            // 
            txtMu.Location = new Point(184, 59);
            txtMu.Margin = new Padding(3, 2, 3, 2);
            txtMu.Name = "txtMu";
            txtMu.Size = new Size(62, 23);
            txtMu.TabIndex = 17;
            // 
            // txtLambda
            // 
            txtLambda.Location = new Point(184, 31);
            txtLambda.Margin = new Padding(3, 2, 3, 2);
            txtLambda.Name = "txtLambda";
            txtLambda.Size = new Size(62, 23);
            txtLambda.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 61);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 15;
            label3.Text = "Velocidad de servicio (μ):";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 33);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 14;
            label2.Text = "Velocidad de llegada (λ):";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 4);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 13;
            label1.Text = "INGRESAR DATOS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label6.Location = new Point(222, 88);
            label6.Name = "label6";
            label6.Size = new Size(83, 15);
            label6.TabIndex = 28;
            label6.Text = "[clientes/hora]";
            // 
            // txtDesvio
            // 
            txtDesvio.Location = new Point(156, 86);
            txtDesvio.Margin = new Padding(3, 2, 3, 2);
            txtDesvio.Name = "txtDesvio";
            txtDesvio.Size = new Size(62, 23);
            txtDesvio.TabIndex = 27;
            // 
            // lblDesvioEstandar
            // 
            lblDesvioEstandar.AutoSize = true;
            lblDesvioEstandar.Location = new Point(29, 89);
            lblDesvioEstandar.Name = "lblDesvioEstandar";
            lblDesvioEstandar.Size = new Size(104, 15);
            lblDesvioEstandar.TabIndex = 26;
            lblDesvioEstandar.Text = "Desvio estadar (θ):";
            // 
            // cbCuadrado
            // 
            cbCuadrado.AutoSize = true;
            cbCuadrado.Location = new Point(311, 90);
            cbCuadrado.Name = "cbCuadrado";
            cbCuadrado.Size = new Size(15, 14);
            cbCuadrado.TabIndex = 29;
            cbCuadrado.UseVisualStyleBackColor = true;
            cbCuadrado.CheckedChanged += cbCuadrado_CheckedChanged;
            // 
            // MG1___MD1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(560, 292);
            Controls.Add(cbCuadrado);
            Controls.Add(label6);
            Controls.Add(txtDesvio);
            Controls.Add(lblDesvioEstandar);
            Controls.Add(btnResetear);
            Controls.Add(panel1);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Controls.Add(cbTipoCalculo);
            Controls.Add(btnCalcular);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtMu);
            Controls.Add(txtLambda);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "MG1___MD1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MG1 / MD1";
            FormClosing += MG1___MD1_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnResetear;
        private Panel panel1;
        private Label lblResultado;
        private Label label7;
        private TextBox txtN;
        private Label lblN;
        private ComboBox cbTipoCalculo;
        private Button btnCalcular;
        private Label label5;
        private Label label4;
        private TextBox txtMu;
        private TextBox txtLambda;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label6;
        private TextBox txtDesvio;
        private Label lblDesvioEstandar;
        private CheckBox cbCuadrado;
    }
}