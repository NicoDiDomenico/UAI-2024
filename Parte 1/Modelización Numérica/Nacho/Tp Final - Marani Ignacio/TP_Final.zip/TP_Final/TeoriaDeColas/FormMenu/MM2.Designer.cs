﻿namespace Vista
{
    partial class MM2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnResetear = new Button();
            panel1 = new Panel();
            lblResultado = new Label();
            label7 = new Label();
            txtN = new TextBox();
            lblN = new Label();
            cbTipoCalculo = new ComboBox();
            btnCalcular = new Button();
            lblclihor2 = new Label();
            lblclihor1 = new Label();
            txtMu1 = new TextBox();
            txtLambda = new TextBox();
            lblServicio1 = new Label();
            lblLlegada = new Label();
            label1 = new Label();
            lblclihor3 = new Label();
            txtMu2 = new TextBox();
            lblServicio2 = new Label();
            cbTipoMM2 = new ComboBox();
            label9 = new Label();
            lblHora2 = new Label();
            lblHora1 = new Label();
            txtTs2 = new TextBox();
            txtTs1 = new TextBox();
            lblTiempoMedio2 = new Label();
            lblTiempoMedio1 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnResetear
            // 
            btnResetear.BackColor = Color.Gold;
            btnResetear.Location = new Point(530, 4);
            btnResetear.Margin = new Padding(3, 2, 3, 2);
            btnResetear.Name = "btnResetear";
            btnResetear.Size = new Size(82, 22);
            btnResetear.TabIndex = 25;
            btnResetear.Text = "Resetear";
            btnResetear.TextImageRelation = TextImageRelation.TextAboveImage;
            btnResetear.UseVisualStyleBackColor = false;
            btnResetear.Click += btnResetear_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SpringGreen;
            panel1.Controls.Add(lblResultado);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 211);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(629, 98);
            panel1.TabIndex = 24;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(10, 34);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(51, 15);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Solution";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 8);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 0;
            label7.Text = "Resultado:";
            // 
            // txtN
            // 
            txtN.Location = new Point(458, 179);
            txtN.Margin = new Padding(3, 2, 3, 2);
            txtN.Name = "txtN";
            txtN.Size = new Size(29, 23);
            txtN.TabIndex = 19;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Location = new Point(425, 181);
            lblN.Name = "lblN";
            lblN.Size = new Size(25, 15);
            lblN.TabIndex = 22;
            lblN.Text = "n =";
            // 
            // cbTipoCalculo
            // 
            cbTipoCalculo.FormattingEnabled = true;
            cbTipoCalculo.Location = new Point(30, 152);
            cbTipoCalculo.Margin = new Padding(3, 2, 3, 2);
            cbTipoCalculo.Name = "cbTipoCalculo";
            cbTipoCalculo.Size = new Size(457, 23);
            cbTipoCalculo.TabIndex = 21;
            cbTipoCalculo.SelectedIndexChanged += cbTipoCalculo_SelectedIndexChanged;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(530, 151);
            btnCalcular.Margin = new Padding(3, 2, 3, 2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(82, 22);
            btnCalcular.TabIndex = 20;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblclihor2
            // 
            lblclihor2.AutoSize = true;
            lblclihor2.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblclihor2.Location = new Point(246, 92);
            lblclihor2.Name = "lblclihor2";
            lblclihor2.Size = new Size(83, 15);
            lblclihor2.TabIndex = 19;
            lblclihor2.Text = "[clientes/hora]";
            // 
            // lblclihor1
            // 
            lblclihor1.AutoSize = true;
            lblclihor1.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblclihor1.Location = new Point(246, 64);
            lblclihor1.Name = "lblclihor1";
            lblclihor1.Size = new Size(83, 15);
            lblclihor1.TabIndex = 18;
            lblclihor1.Text = "[clientes/hora]";
            // 
            // txtMu1
            // 
            txtMu1.Location = new Point(180, 90);
            txtMu1.Margin = new Padding(3, 2, 3, 2);
            txtMu1.Name = "txtMu1";
            txtMu1.Size = new Size(62, 23);
            txtMu1.TabIndex = 17;
            // 
            // txtLambda
            // 
            txtLambda.Location = new Point(180, 62);
            txtLambda.Margin = new Padding(3, 2, 3, 2);
            txtLambda.Name = "txtLambda";
            txtLambda.Size = new Size(62, 23);
            txtLambda.TabIndex = 16;
            // 
            // lblServicio1
            // 
            lblServicio1.AutoSize = true;
            lblServicio1.Location = new Point(30, 93);
            lblServicio1.Name = "lblServicio1";
            lblServicio1.Size = new Size(144, 15);
            lblServicio1.TabIndex = 15;
            lblServicio1.Text = "Velocidad de servicio (μ1):";
            // 
            // lblLlegada
            // 
            lblLlegada.AutoSize = true;
            lblLlegada.Location = new Point(30, 65);
            lblLlegada.Name = "lblLlegada";
            lblLlegada.Size = new Size(135, 15);
            lblLlegada.TabIndex = 14;
            lblLlegada.Text = "Velocidad de llegada (λ):";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 4);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 13;
            label1.Text = "INGRESAR DATOS";
            // 
            // lblclihor3
            // 
            lblclihor3.AutoSize = true;
            lblclihor3.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblclihor3.Location = new Point(246, 119);
            lblclihor3.Name = "lblclihor3";
            lblclihor3.Size = new Size(83, 15);
            lblclihor3.TabIndex = 28;
            lblclihor3.Text = "[clientes/hora]";
            // 
            // txtMu2
            // 
            txtMu2.Location = new Point(180, 117);
            txtMu2.Margin = new Padding(3, 2, 3, 2);
            txtMu2.Name = "txtMu2";
            txtMu2.Size = new Size(62, 23);
            txtMu2.TabIndex = 18;
            // 
            // lblServicio2
            // 
            lblServicio2.AutoSize = true;
            lblServicio2.Location = new Point(30, 120);
            lblServicio2.Name = "lblServicio2";
            lblServicio2.Size = new Size(144, 15);
            lblServicio2.TabIndex = 26;
            lblServicio2.Text = "Velocidad de servicio (μ2):";
            // 
            // cbTipoMM2
            // 
            cbTipoMM2.FormattingEnabled = true;
            cbTipoMM2.Location = new Point(113, 32);
            cbTipoMM2.Margin = new Padding(3, 2, 3, 2);
            cbTipoMM2.Name = "cbTipoMM2";
            cbTipoMM2.Size = new Size(374, 23);
            cbTipoMM2.TabIndex = 29;
            cbTipoMM2.SelectedIndexChanged += cbTipoMM2_SelectedIndexChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(30, 35);
            label9.Name = "label9";
            label9.Size = new Size(77, 15);
            label9.TabIndex = 30;
            label9.Text = "Tipo de MM2";
            // 
            // lblHora2
            // 
            lblHora2.AutoSize = true;
            lblHora2.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblHora2.Location = new Point(543, 92);
            lblHora2.Name = "lblHora2";
            lblHora2.Size = new Size(44, 15);
            lblHora2.TabIndex = 36;
            lblHora2.Text = "[horas]";
            // 
            // lblHora1
            // 
            lblHora1.AutoSize = true;
            lblHora1.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblHora1.Location = new Point(543, 64);
            lblHora1.Name = "lblHora1";
            lblHora1.Size = new Size(44, 15);
            lblHora1.TabIndex = 35;
            lblHora1.Text = "[horas]";
            // 
            // txtTs2
            // 
            txtTs2.Location = new Point(477, 90);
            txtTs2.Margin = new Padding(3, 2, 3, 2);
            txtTs2.Name = "txtTs2";
            txtTs2.Size = new Size(62, 23);
            txtTs2.TabIndex = 34;
            // 
            // txtTs1
            // 
            txtTs1.Location = new Point(477, 62);
            txtTs1.Margin = new Padding(3, 2, 3, 2);
            txtTs1.Name = "txtTs1";
            txtTs1.Size = new Size(62, 23);
            txtTs1.TabIndex = 33;
            // 
            // lblTiempoMedio2
            // 
            lblTiempoMedio2.AutoSize = true;
            lblTiempoMedio2.Location = new Point(338, 94);
            lblTiempoMedio2.Name = "lblTiempoMedio2";
            lblTiempoMedio2.Size = new Size(133, 15);
            lblTiempoMedio2.TabIndex = 32;
            lblTiempoMedio2.Text = "Tiempo medio CLASE 2:";
            // 
            // lblTiempoMedio1
            // 
            lblTiempoMedio1.AutoSize = true;
            lblTiempoMedio1.Location = new Point(338, 66);
            lblTiempoMedio1.Name = "lblTiempoMedio1";
            lblTiempoMedio1.Size = new Size(133, 15);
            lblTiempoMedio1.TabIndex = 31;
            lblTiempoMedio1.Text = "Tiempo medio CLASE 1:";
            // 
            // MM2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(629, 309);
            Controls.Add(lblHora2);
            Controls.Add(lblHora1);
            Controls.Add(txtTs2);
            Controls.Add(txtTs1);
            Controls.Add(lblTiempoMedio2);
            Controls.Add(lblTiempoMedio1);
            Controls.Add(label9);
            Controls.Add(cbTipoMM2);
            Controls.Add(lblclihor3);
            Controls.Add(txtMu2);
            Controls.Add(lblServicio2);
            Controls.Add(btnResetear);
            Controls.Add(panel1);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Controls.Add(cbTipoCalculo);
            Controls.Add(btnCalcular);
            Controls.Add(lblclihor2);
            Controls.Add(lblclihor1);
            Controls.Add(txtMu1);
            Controls.Add(txtLambda);
            Controls.Add(lblServicio1);
            Controls.Add(lblLlegada);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "MM2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MM2";
            FormClosing += MM2_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnResetear;
        private Panel panel1;
        private Label lblResultado;
        private Label label7;
        private TextBox txtN;
        private Label lblN;
        private ComboBox cbTipoCalculo;
        private Button btnCalcular;
        private Label lblclihor2;
        private Label lblclihor1;
        private TextBox txtMu1;
        private TextBox txtLambda;
        private Label lblServicio1;
        private Label lblLlegada;
        private Label label1;
        private Label lblclihor3;
        private TextBox txtMu2;
        private Label lblServicio2;
        private ComboBox cbTipoMM2;
        private Label label9;
        private Label lblHora2;
        private Label lblHora1;
        private TextBox txtTs2;
        private TextBox txtTs1;
        private Label lblTiempoMedio2;
        private Label lblTiempoMedio1;
    }
}