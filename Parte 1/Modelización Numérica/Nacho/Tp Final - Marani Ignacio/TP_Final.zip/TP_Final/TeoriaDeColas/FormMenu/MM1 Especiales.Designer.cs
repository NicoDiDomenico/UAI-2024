﻿namespace Vista
{
    partial class MM1_Especiales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label9 = new Label();
            cbTipoMM1 = new ComboBox();
            btnResetear = new Button();
            panel1 = new Panel();
            lblResultado = new Label();
            label7 = new Label();
            txtN = new TextBox();
            lblN = new Label();
            cbTipoCalculo = new ComboBox();
            btnCalcular = new Button();
            label5 = new Label();
            label4 = new Label();
            txtMu = new TextBox();
            txtLambda = new TextBox();
            label3 = new Label();
            lbllambda1 = new Label();
            label1 = new Label();
            lbl_cli_hor = new Label();
            txtLambda2 = new TextBox();
            lbllambda2 = new Label();
            lblCiclos = new Label();
            txtCiclos = new TextBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(30, 33);
            label9.Name = "label9";
            label9.Size = new Size(77, 15);
            label9.TabIndex = 48;
            label9.Text = "Tipo de MM1";
            // 
            // cbTipoMM1
            // 
            cbTipoMM1.FormattingEnabled = true;
            cbTipoMM1.Location = new Point(113, 30);
            cbTipoMM1.Margin = new Padding(3, 2, 3, 2);
            cbTipoMM1.Name = "cbTipoMM1";
            cbTipoMM1.Size = new Size(332, 23);
            cbTipoMM1.TabIndex = 47;
            cbTipoMM1.SelectedIndexChanged += cbTipoMM1_SelectedIndexChanged;
            // 
            // btnResetear
            // 
            btnResetear.BackColor = Color.Gold;
            btnResetear.Location = new Point(467, 2);
            btnResetear.Margin = new Padding(3, 2, 3, 2);
            btnResetear.Name = "btnResetear";
            btnResetear.Size = new Size(82, 22);
            btnResetear.TabIndex = 44;
            btnResetear.Text = "Resetear";
            btnResetear.TextImageRelation = TextImageRelation.TextAboveImage;
            btnResetear.UseVisualStyleBackColor = false;
            btnResetear.Click += btnResetear_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SpringGreen;
            panel1.Controls.Add(lblResultado);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 209);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(674, 98);
            panel1.TabIndex = 43;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(10, 34);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(51, 15);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Solution";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 8);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 0;
            label7.Text = "Resultado:";
            // 
            // txtN
            // 
            txtN.Location = new Point(416, 165);
            txtN.Margin = new Padding(3, 2, 3, 2);
            txtN.Name = "txtN";
            txtN.Size = new Size(29, 23);
            txtN.TabIndex = 39;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Location = new Point(383, 167);
            lblN.Name = "lblN";
            lblN.Size = new Size(25, 15);
            lblN.TabIndex = 42;
            lblN.Text = "n =";
            // 
            // cbTipoCalculo
            // 
            cbTipoCalculo.FormattingEnabled = true;
            cbTipoCalculo.Location = new Point(30, 139);
            cbTipoCalculo.Margin = new Padding(3, 2, 3, 2);
            cbTipoCalculo.Name = "cbTipoCalculo";
            cbTipoCalculo.Size = new Size(415, 23);
            cbTipoCalculo.TabIndex = 41;
            cbTipoCalculo.SelectedIndexChanged += cbTipoCalculo_SelectedIndexChanged;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(468, 139);
            btnCalcular.Margin = new Padding(3, 2, 3, 2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(82, 22);
            btnCalcular.TabIndex = 40;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label5.Location = new Point(241, 101);
            label5.Name = "label5";
            label5.Size = new Size(83, 15);
            label5.TabIndex = 38;
            label5.Text = "[clientes/hora]";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label4.Location = new Point(241, 73);
            label4.Name = "label4";
            label4.Size = new Size(83, 15);
            label4.TabIndex = 37;
            label4.Text = "[clientes/hora]";
            // 
            // txtMu
            // 
            txtMu.Location = new Point(175, 99);
            txtMu.Margin = new Padding(3, 2, 3, 2);
            txtMu.Name = "txtMu";
            txtMu.Size = new Size(62, 23);
            txtMu.TabIndex = 35;
            // 
            // txtLambda
            // 
            txtLambda.Location = new Point(175, 71);
            txtLambda.Margin = new Padding(3, 2, 3, 2);
            txtLambda.Name = "txtLambda";
            txtLambda.Size = new Size(62, 23);
            txtLambda.TabIndex = 34;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 101);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 33;
            label3.Text = "Velocidad de servicio (μ):";
            // 
            // lbllambda1
            // 
            lbllambda1.AutoSize = true;
            lbllambda1.Location = new Point(30, 73);
            lbllambda1.Name = "lbllambda1";
            lbllambda1.Size = new Size(135, 15);
            lbllambda1.TabIndex = 32;
            lbllambda1.Text = "Velocidad de llegada (λ):";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 2);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 31;
            label1.Text = "INGRESAR DATOS";
            // 
            // lbl_cli_hor
            // 
            lbl_cli_hor.AutoSize = true;
            lbl_cli_hor.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lbl_cli_hor.Location = new Point(574, 73);
            lbl_cli_hor.Name = "lbl_cli_hor";
            lbl_cli_hor.Size = new Size(83, 15);
            lbl_cli_hor.TabIndex = 51;
            lbl_cli_hor.Text = "[clientes/hora]";
            // 
            // txtLambda2
            // 
            txtLambda2.Location = new Point(508, 71);
            txtLambda2.Margin = new Padding(3, 2, 3, 2);
            txtLambda2.Name = "txtLambda2";
            txtLambda2.Size = new Size(62, 23);
            txtLambda2.TabIndex = 49;
            // 
            // lbllambda2
            // 
            lbllambda2.AutoSize = true;
            lbllambda2.Location = new Point(363, 73);
            lbllambda2.Name = "lbllambda2";
            lbllambda2.Size = new Size(141, 15);
            lbllambda2.TabIndex = 50;
            lbllambda2.Text = "Velocidad de llegada (λ2):";
            // 
            // lblCiclos
            // 
            lblCiclos.AutoSize = true;
            lblCiclos.Location = new Point(468, 33);
            lblCiclos.Name = "lblCiclos";
            lblCiclos.Size = new Size(42, 15);
            lblCiclos.TabIndex = 52;
            lblCiclos.Text = "Ciclos:";
            // 
            // txtCiclos
            // 
            txtCiclos.Location = new Point(518, 30);
            txtCiclos.Margin = new Padding(3, 2, 3, 2);
            txtCiclos.Name = "txtCiclos";
            txtCiclos.Size = new Size(29, 23);
            txtCiclos.TabIndex = 53;
            // 
            // MM1_Especiales
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(674, 307);
            Controls.Add(txtCiclos);
            Controls.Add(lblCiclos);
            Controls.Add(lbl_cli_hor);
            Controls.Add(txtLambda2);
            Controls.Add(lbllambda2);
            Controls.Add(label9);
            Controls.Add(cbTipoMM1);
            Controls.Add(btnResetear);
            Controls.Add(panel1);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Controls.Add(cbTipoCalculo);
            Controls.Add(btnCalcular);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtMu);
            Controls.Add(txtLambda);
            Controls.Add(label3);
            Controls.Add(lbllambda1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "MM1_Especiales";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MM1_Especiales";
            FormClosing += MM1_Especiales_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label9;
        private ComboBox cbTipoMM1;
        private Button btnResetear;
        private Panel panel1;
        private Label lblResultado;
        private Label label7;
        private TextBox txtN;
        private Label lblN;
        private ComboBox cbTipoCalculo;
        private Button btnCalcular;
        private Label label5;
        private Label label4;
        private TextBox txtMu;
        private TextBox txtLambda;
        private Label label3;
        private Label lbllambda1;
        private Label label1;
        private Label lbl_cli_hor;
        private TextBox txtLambda2;
        private Label lbllambda2;
        private Label lblCiclos;
        private TextBox txtCiclos;
    }
}