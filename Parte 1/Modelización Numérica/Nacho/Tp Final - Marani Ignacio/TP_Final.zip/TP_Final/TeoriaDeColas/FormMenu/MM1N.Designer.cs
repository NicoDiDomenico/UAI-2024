﻿namespace Vista
{
    partial class MM1N
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnResetear = new Button();
            txtN = new TextBox();
            lblN = new Label();
            cbTipoCalculo = new ComboBox();
            btnCalcular = new Button();
            label5 = new Label();
            label4 = new Label();
            txtMu = new TextBox();
            txtLambda = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label7 = new Label();
            panel1 = new Panel();
            lblResultado = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnResetear
            // 
            btnResetear.BackColor = Color.Gold;
            btnResetear.Location = new Point(555, 3);
            btnResetear.Margin = new Padding(3, 2, 3, 2);
            btnResetear.Name = "btnResetear";
            btnResetear.Size = new Size(82, 22);
            btnResetear.TabIndex = 25;
            btnResetear.Text = "Resetear";
            btnResetear.TextImageRelation = TextImageRelation.TextAboveImage;
            btnResetear.UseVisualStyleBackColor = false;
            btnResetear.Click += btnResetear_Click;
            // 
            // txtN
            // 
            txtN.Location = new Point(508, 122);
            txtN.Margin = new Padding(3, 2, 3, 2);
            txtN.Name = "txtN";
            txtN.Size = new Size(29, 23);
            txtN.TabIndex = 23;
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Location = new Point(475, 124);
            lblN.Name = "lblN";
            lblN.Size = new Size(25, 15);
            lblN.TabIndex = 22;
            lblN.Text = "n =";
            // 
            // cbTipoCalculo
            // 
            cbTipoCalculo.FormattingEnabled = true;
            cbTipoCalculo.Location = new Point(29, 97);
            cbTipoCalculo.Margin = new Padding(3, 2, 3, 2);
            cbTipoCalculo.Name = "cbTipoCalculo";
            cbTipoCalculo.Size = new Size(508, 23);
            cbTipoCalculo.TabIndex = 21;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(555, 96);
            btnCalcular.Margin = new Padding(3, 2, 3, 2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(82, 22);
            btnCalcular.TabIndex = 20;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label5.Location = new Point(250, 60);
            label5.Name = "label5";
            label5.Size = new Size(83, 15);
            label5.TabIndex = 19;
            label5.Text = "[clientes/hora]";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            label4.Location = new Point(250, 32);
            label4.Name = "label4";
            label4.Size = new Size(83, 15);
            label4.TabIndex = 18;
            label4.Text = "[clientes/hora]";
            // 
            // txtMu
            // 
            txtMu.Location = new Point(184, 58);
            txtMu.Margin = new Padding(3, 2, 3, 2);
            txtMu.Name = "txtMu";
            txtMu.Size = new Size(62, 23);
            txtMu.TabIndex = 17;
            // 
            // txtLambda
            // 
            txtLambda.Location = new Point(184, 30);
            txtLambda.Margin = new Padding(3, 2, 3, 2);
            txtLambda.Name = "txtLambda";
            txtLambda.Size = new Size(62, 23);
            txtLambda.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 60);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 15;
            label3.Text = "Velocidad de servicio (μ):";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 32);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 14;
            label2.Text = "Velocidad de llegada (λ):";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 3);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 13;
            label1.Text = "INGRESAR DATOS";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 8);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 0;
            label7.Text = "Resultado:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SpringGreen;
            panel1.Controls.Add(lblResultado);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 161);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(648, 98);
            panel1.TabIndex = 24;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(10, 34);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(51, 15);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Solution";
            // 
            // MM1N
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(648, 259);
            Controls.Add(btnResetear);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Controls.Add(cbTipoCalculo);
            Controls.Add(btnCalcular);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtMu);
            Controls.Add(txtLambda);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            Name = "MM1N";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MM1N";
            FormClosing += MM1N_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnResetear;
        private TextBox txtN;
        private Label lblN;
        private ComboBox cbTipoCalculo;
        private Button btnCalcular;
        private Label label5;
        private Label label4;
        private TextBox txtMu;
        private TextBox txtLambda;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label7;
        private Panel panel1;
        private Label lblResultado;
    }
}