﻿namespace FormMenu
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMM1 = new Button();
            btnMM1N = new Button();
            label1 = new Label();
            label2 = new Label();
            btnMM2 = new Button();
            btnMG1_MD1 = new Button();
            btnMM1Especiales = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // btnMM1
            // 
            btnMM1.BackColor = Color.DimGray;
            btnMM1.Font = new Font("Tahoma", 9F, FontStyle.Bold);
            btnMM1.ForeColor = Color.White;
            btnMM1.Location = new Point(18, 36);
            btnMM1.Margin = new Padding(3, 2, 3, 2);
            btnMM1.Name = "btnMM1";
            btnMM1.Size = new Size(166, 33);
            btnMM1.TabIndex = 0;
            btnMM1.Text = "M/M/1";
            btnMM1.UseVisualStyleBackColor = false;
            btnMM1.Click += btnMM1_Click;
            // 
            // btnMM1N
            // 
            btnMM1N.BackColor = Color.DimGray;
            btnMM1N.Font = new Font("Tahoma", 9F, FontStyle.Bold);
            btnMM1N.ForeColor = Color.White;
            btnMM1N.Location = new Point(190, 36);
            btnMM1N.Margin = new Padding(3, 2, 3, 2);
            btnMM1N.Name = "btnMM1N";
            btnMM1N.Size = new Size(166, 33);
            btnMM1N.TabIndex = 1;
            btnMM1N.Text = "M/M/1/N";
            btnMM1N.UseVisualStyleBackColor = false;
            btnMM1N.Click += btnMM1N_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(319, 19);
            label1.TabIndex = 2;
            label1.Text = "CALCULADORA MODELIZACIÓN NUMÉRICA";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(193, 124);
            label2.Name = "label2";
            label2.Size = new Size(86, 15);
            label2.TabIndex = 3;
            label2.Text = "Marani Ignacio";
            // 
            // btnMM2
            // 
            btnMM2.BackColor = Color.DimGray;
            btnMM2.Font = new Font("Tahoma", 9F, FontStyle.Bold);
            btnMM2.ForeColor = Color.White;
            btnMM2.Location = new Point(190, 80);
            btnMM2.Margin = new Padding(3, 2, 3, 2);
            btnMM2.Name = "btnMM2";
            btnMM2.Size = new Size(166, 33);
            btnMM2.TabIndex = 5;
            btnMM2.Text = "M/M/2";
            btnMM2.UseVisualStyleBackColor = false;
            btnMM2.Click += btnMM2_Click;
            // 
            // btnMG1_MD1
            // 
            btnMG1_MD1.BackColor = Color.DimGray;
            btnMG1_MD1.Font = new Font("Tahoma", 9F, FontStyle.Bold);
            btnMG1_MD1.ForeColor = Color.White;
            btnMG1_MD1.Location = new Point(18, 124);
            btnMG1_MD1.Margin = new Padding(3, 2, 3, 2);
            btnMG1_MD1.Name = "btnMG1_MD1";
            btnMG1_MD1.Size = new Size(166, 33);
            btnMG1_MD1.TabIndex = 6;
            btnMG1_MD1.Text = "M/G/1 - M/D/1";
            btnMG1_MD1.UseVisualStyleBackColor = false;
            btnMG1_MD1.Click += btnMG1_MD1_Click;
            // 
            // btnMM1Especiales
            // 
            btnMM1Especiales.BackColor = Color.DimGray;
            btnMM1Especiales.Font = new Font("Tahoma", 9F, FontStyle.Bold);
            btnMM1Especiales.ForeColor = Color.White;
            btnMM1Especiales.Location = new Point(18, 80);
            btnMM1Especiales.Margin = new Padding(3, 2, 3, 2);
            btnMM1Especiales.Name = "btnMM1Especiales";
            btnMM1Especiales.Size = new Size(166, 33);
            btnMM1Especiales.TabIndex = 7;
            btnMM1Especiales.Text = "M/M/1 Especiales";
            btnMM1Especiales.UseVisualStyleBackColor = false;
            btnMM1Especiales.Click += btnMM1Especiales_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.Control;
            label3.Location = new Point(267, 142);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 8;
            label3.Text = "Calvo Santiago ";
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Red;
            ClientSize = new Size(375, 177);
            Controls.Add(label3);
            Controls.Add(btnMM1Especiales);
            Controls.Add(btnMG1_MD1);
            Controls.Add(btnMM2);
            Controls.Add(label2);
            Controls.Add(btnMM1N);
            Controls.Add(btnMM1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu";
            FormClosing += Menu_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnMM1;
        private Button btnMM1N;
        private Label label1;
        private Label label2;
        private Button btnMM2;
        private Button btnMG1_MD1;
        private Button btnMM1Especiales;
        private Label label3;
    }
}
