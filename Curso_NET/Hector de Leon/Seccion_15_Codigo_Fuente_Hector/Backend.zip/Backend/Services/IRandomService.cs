﻿namespace Backend.Services
{
    public interface IRandomService
    {
        public int Value { get; }
    }
}
