/*
**            Inspect_corporation.SQL
**
**  This script uses the sp_help system stored
**  procedure to examine the corporation table.
*/

USE credit
GO

sp_help corporation
GO
