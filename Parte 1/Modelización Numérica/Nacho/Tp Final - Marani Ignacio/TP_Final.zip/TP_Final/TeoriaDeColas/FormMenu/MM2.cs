﻿using ExtendedNumerics;
using FormMenu;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class MM2 : Form
    {
        public MM2()
        {
            InitializeComponent();       
            cbTipoMM2.Items.Clear();
            cbTipoMM2.Items.Add("Servidores de igual velocidad");
            cbTipoMM2.Items.Add("Servidores de distinta velocidad - Con selección de servidor");
            cbTipoMM2.Items.Add("Servidores de distinta velocidad - Sin selección de servidor");
            cbTipoMM2.Items.Add("Sin interrupción de servicio");
            lblResultado.Text = string.Empty;
            lblN.Visible = false;
            txtN.Visible = false;
            lblTiempoMedio1.Visible = false;
            lblTiempoMedio2.Visible = false;
            txtTs1.Visible = false;
            txtTs2.Visible = false;
            lblHora1.Visible = false;
            lblHora2.Visible = false;
        }

        private void MM2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            var formMenu = new Menu();
            formMenu.ShowDialog();
        }

        private void cbTipoCalculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)" || cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)" || cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
            {
                lblN.Visible = true;
                txtN.Visible = true;
            }
            else
            {
                lblN.Visible = false;
                txtN.Visible = false;
            }
        }

        public bool ValidarDatos()
        {
            decimal lambda;
            if (!decimal.TryParse(txtLambda.Text, out lambda))
            {
                MessageBox.Show("Ingrese el λ correctamente");
                return false;
            }

            decimal mu1;
            if (!decimal.TryParse(txtMu1.Text, out mu1))
            {
                MessageBox.Show("Ingrese el μ1 correctamente");
                return false;
            }

            decimal mu2;
            if (!decimal.TryParse(txtMu2.Text, out mu2))
            {
                MessageBox.Show("Ingrese el μ2 correctamente");
                return false;
            }
            return true;
        }

        public bool ValidarDatos2()
        {
            decimal w0;
            if (!decimal.TryParse(txtLambda.Text, out w0))
            {
                MessageBox.Show("Ingrese el W0 correctamente");
                return false;
            }

            decimal w1;
            if (!decimal.TryParse(txtMu1.Text, out w1))
            {
                MessageBox.Show("Ingrese Q1 correctamente");
                return false;
            }

            decimal w2;
            if (!decimal.TryParse(txtMu2.Text, out w2))
            {
                MessageBox.Show("Ingrese Q2 correctamente");
                return false;
            }

            decimal Ts1;
            if (!decimal.TryParse(txtTs1.Text, out Ts1))
            {
                MessageBox.Show("Ingrese el Ts1 correctamente");
                return false;
            }

            decimal Ts2;
            if (!decimal.TryParse(txtTs2.Text, out Ts2))
            {
                MessageBox.Show("Ingrese el Ts2 correctamente");
                return false;
            }
            return true;
        }

        private void cbTipoMM2_SelectedIndexChanged(object sender, EventArgs e)
        {            
            if (cbTipoMM2.Text == "Servidores de igual velocidad")
            {
                cbTipoCalculo.Items.Clear();
                cbTipoCalculo.Items.Add("Factor de uso (P)");
                cbTipoCalculo.Items.Add("Tiempo entre llegada (1/λ)");
                cbTipoCalculo.Items.Add("Tiempo entre servicio (1/μ)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en el sistema (Ls)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en la cola (Lq)");
                cbTipoCalculo.Items.Add("Tiempo en el sistema (Ws)");
                cbTipoCalculo.Items.Add("Tiempo en la cola (Wq)");
                cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
                cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
                cbTipoCalculo.Items.Add("Probabilidad de al menos n unidades en el sistema (Pan)");
                cbTipoCalculo.Items.Add("Probabilidad de a lo sumo n unidades en el sistema (Psn)");
                lblLlegada.Text = "Velocidad de llegada (λ):";
                lblServicio1.Text = "Velocidad de servicio (μ1):";
                lblServicio2.Text = "Velocidad de servicio (μ2):";
                lblclihor1.Text = "[clientes/hora]";
                lblclihor2.Text = "[clientes/hora]";
                lblclihor3.Text = "[clientes/hora]";
                lblTiempoMedio1.Visible = false;
                lblTiempoMedio2.Visible = false;
                txtTs1.Visible = false;
                txtTs2.Visible = false;
                lblHora1.Visible = false;
                lblHora2.Visible = false;   
            }
            if (cbTipoMM2.Text == "Sin interrupción de servicio")
            {
                cbTipoCalculo.Items.Clear();
                cbTipoCalculo.Items.Add("Tiempo cliente Clase 1 en el sistema (Ws1)");
                cbTipoCalculo.Items.Add("Tiempo cliente Clase 1 en la cola (Wq1)");
                lblLlegada.Text = "Tiempo restante (Wo):";
                lblServicio1.Text = "Clientes CLASE 1 (Q1):";
                lblServicio2.Text = "Clientes CLASE 2 (Q2):";
                lblclihor1.Text = "[horas]";
                lblclihor2.Text = "[clientes]"; 
                lblclihor3.Text = "[clientes]";
                lblTiempoMedio1.Visible = true;
                lblTiempoMedio2.Visible = true;
                txtTs1.Visible = true;
                txtTs2.Visible = true;
                lblHora1.Visible = true;
                lblHora2.Visible = true;
            }
            else
            {
                cbTipoCalculo.Items.Clear();
                cbTipoCalculo.Items.Add("Factor de uso (P)");
                cbTipoCalculo.Items.Add("Tiempo entre llegada (1/λ)");
                cbTipoCalculo.Items.Add("Tiempo entre servicio (1/μ)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en el sistema (Ls)");
                cbTipoCalculo.Items.Add("Cantidad de unidades en la cola (Lq)");
                cbTipoCalculo.Items.Add("Tiempo en el sistema (Ws)");
                cbTipoCalculo.Items.Add("Tiempo en la cola (Wq)");
                cbTipoCalculo.Items.Add("Probabilidad de cero unidades en el sistema (Po)");
                cbTipoCalculo.Items.Add("Probabilidad de n unidades en el sistema (Pn)");
                cbTipoCalculo.Items.Add("Probabilidad de al menos n unidades en el sistema (Pan)");
                cbTipoCalculo.Items.Add("Probabilidad de a lo sumo n unidades en el sistema (Psn)");
                cbTipoCalculo.Items.Add("Factor de uso crítico (Pc)");
                lblLlegada.Text = "Velocidad de llegada (λ):";
                lblServicio1.Text = "Velocidad de servicio (μ1):";
                lblServicio2.Text = "Velocidad de servicio (μ2):";
                lblclihor1.Text = "[clientes/hora]";
                lblclihor2.Text = "[clientes/hora]";
                lblclihor3.Text = "[clientes/hora]";
                lblTiempoMedio1.Visible = false;
                lblTiempoMedio2.Visible = false;
                txtTs1.Visible = false;
                txtTs2.Visible = false;
                lblHora1.Visible = false;
                lblHora2.Visible = false;
            }
        }

        private void btnResetear_Click(object sender, EventArgs e)
        {
            txtLambda.Text = string.Empty;
            txtMu1.Text = string.Empty;
            txtMu2.Text = string.Empty;
            txtN.Text = string.Empty;
            txtTs1.Text = string.Empty;
            txtTs2.Text = string.Empty;
            lblResultado.Text = string.Empty;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbTipoMM2.Text == "Servidores de igual velocidad")
                {
                    if (!ValidarDatos())
                    {
                        return;
                    }

                    BigDecimal lambda = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal mu1 = BigDecimal.Parse(txtMu1.Text);
                    BigDecimal mu2 = BigDecimal.Parse(txtMu2.Text);
                    int n;

                    if (mu1 != mu2)
                    {
                        MessageBox.Show("Las velocidades de los servidores deben ser iguales");
                        return;
                    }

                    if (cbTipoCalculo.Text == "Factor de uso (P)")
                    {
                        BigDecimal resultado = lambda / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre llegada (1/λ)")
                    {
                        BigDecimal resultado = BigDecimal.One / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre llegada (1/λ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre servicio (1/μ)")
                    {
                        BigDecimal resultado = BigDecimal.One / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre servicio (1/μ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en el sistema (Ls)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = P / (BigDecimal.One - P);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en la cola (Lq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = (P * P) / (BigDecimal.One - P);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en el sistema (Ws)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en el sistema (Ws) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Ls = P / (BigDecimal.One - P);
                            BigDecimal resultado = Ls / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en la cola (Wq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en la cola (Wq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Lq = (P * P) / (BigDecimal.One - P);
                            BigDecimal resultado = Lq / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en la cola (Wq) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                    {
                        BigDecimal P = lambda / (mu1 + mu2);
                        BigDecimal resultado = BigDecimal.One - P;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }
                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal pFinal = BigDecimal.One;
                        for (int i = 0; i < n; i++)
                        {
                            pFinal *= pParcial;
                        }

                        BigDecimal resultado = (BigDecimal.One - n) * (pFinal);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal sumatoria = p0;

                        for (int i = 1; i < n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }
                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            sumatoria += pFinal;
                        }

                        BigDecimal resultado = BigDecimal.One - sumatoria;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de al menos n unidades en el sistema (Pan) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = BigDecimal.One - pParcial;
                        BigDecimal resultado = p0;

                        for (int i = 1; i <= n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            resultado += pFinal;
                        }
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de a lo sumo n unidades en el sistema (Psn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }
                }

                if (cbTipoMM2.Text == "Servidores de distinta velocidad - Con selección de servidor")
                {
                    if (!ValidarDatos())
                    {
                        return;
                    }

                    BigDecimal lambda = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal mu1 = BigDecimal.Parse(txtMu1.Text);
                    BigDecimal mu2 = BigDecimal.Parse(txtMu2.Text);
                    int n;

                    if (mu1 == mu2)
                    {
                        MessageBox.Show("Las velocidades de los servidores deben ser distinta");
                        return;
                    }
                    if (mu1 < mu2)
                    {
                        MessageBox.Show("La velocidad del servidor μ1 debe ser mayor a la del servidor μ2");
                        return;
                    }

                    BigDecimal muS = mu1 + mu2;
                    BigDecimal aPrima = ((((2 * lambda) + muS) * (mu1 * mu2)) / (muS * (lambda + mu2)));

                    if (cbTipoCalculo.Text == "Factor de uso (P)")
                    {
                        BigDecimal resultado = lambda / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre llegada (1/λ)")
                    {
                        BigDecimal resultado = BigDecimal.One / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre llegada (1/λ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre servicio (1/μ)")
                    {
                        BigDecimal resultado = BigDecimal.One / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre servicio (1/μ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en el sistema (Ls)")
                    {
                        if (mu1 + mu2 == lambda && aPrima == 0)
                        {
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = lambda / ((BigDecimal.One - P) * (lambda + ((1 - P) * aPrima)));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en la cola (Lq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = (P * P) / (BigDecimal.One - P);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en el sistema (Ws)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en el sistema (Ws) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Ls = lambda / ((BigDecimal.One - P) * (lambda + ((1 - P) * aPrima)));
                            BigDecimal resultado = Ls / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en la cola (Wq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en la cola (Wq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Lq = (P * P) / (BigDecimal.One - P);
                            BigDecimal resultado = Lq / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en la cola (Wq) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                    {
                        BigDecimal P = lambda / (mu1 + mu2);

                        if (1 - P + (lambda / aPrima) == 0)
                        {
                            lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = (BigDecimal.One - P) / (1 - P + (lambda / aPrima));
                            BigDecimal resultadoPorcentual = resultado * 100;
                            resultado = BigDecimal.Round(resultado, 5);
                            resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                            lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }
                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal pFinal = BigDecimal.One;
                        for (int i = 0; i < n; i++)
                        {
                            pFinal *= pParcial;
                        }

                        BigDecimal resultado = (BigDecimal.One - n) * (pFinal);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = (BigDecimal.One - pParcial) / (1 - pParcial + (lambda / aPrima));
                        BigDecimal sumatoria = p0;

                        for (int i = 1; i < n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            sumatoria += pFinal;
                        }

                        BigDecimal resultado = BigDecimal.One - sumatoria;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de al menos " + n + " unidades en el sistema (Pan) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = (BigDecimal.One - pParcial) / (1 - pParcial + (lambda / aPrima));
                        BigDecimal resultado = p0;

                        for (int i = 1; i <= n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            resultado += pFinal;
                        }

                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de a lo sumo n unidades en el sistema (Psn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Factor de uso crítico (Pc)")
                    {
                        double mu1r = Convert.ToDouble(txtMu1.Text);
                        double mu2r = Convert.ToDouble(txtMu2.Text);
                        double r = mu2r / mu1r;
                        double a = (1 + (r * r));
                        double b = -(2 + (r * r));
                        double c = -(2 * r - 1) * (1 + r);
                        double discriminante = b * b - 4 * a * c;
                        if (discriminante >= 0)
                        {
                            double raiz = Math.Sqrt(discriminante);
                            double x1 = (-b + raiz) / (2 * a);
                            double x2 = (-b - raiz) / (2 * a);

                            x1 = double.Round(x1, 5);
                            x2 = double.Round(x2, 5);
                            lblResultado.Text = "El factor de uso crítico (Pc) = " + x1.ToString() + " [clientes / hora] \n" +
                                                "El factor de uso crítico (Pc) = " + x2.ToString() + " [clientes / hora]";
                        }
                    }
                }

                if (cbTipoMM2.Text == "Servidores de distinta velocidad - Sin selección de servidor")
                {
                    if (!ValidarDatos())
                    {
                        return;
                    }

                    BigDecimal lambda = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal mu1 = BigDecimal.Parse(txtMu1.Text);
                    BigDecimal mu2 = BigDecimal.Parse(txtMu2.Text);
                    int n;

                    if (mu1 == mu2)
                    {
                        MessageBox.Show("Las velocidades de los servidores deben ser distinta");
                        return;
                    }
                    if (mu1 < mu2)
                    {
                        MessageBox.Show("La velocidad del servidor μ1 debe ser mayor a la del servidor μ2");
                        return;
                    }

                    BigDecimal a = ((2 * mu1 * mu2) / (mu1 + mu2));

                    if (cbTipoCalculo.Text == "Factor de uso (P)")
                    {
                        BigDecimal resultado = lambda / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso (P) = " + resultado.ToString() + " [clientes / hora]";
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre llegada (1/λ)")
                    {
                        BigDecimal resultado = BigDecimal.One / lambda;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre llegada (1/λ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Tiempo entre servicio (1/μ)")
                    {
                        BigDecimal resultado = BigDecimal.One / (mu1 + mu2);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo entre servicio (1/μ) = " + resultado.ToString();
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en el sistema (Ls)")
                    {
                        if (mu1 + mu2 == lambda && a == 0)
                        {
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = lambda / ((BigDecimal.One - P) * (lambda + ((1 - P) * a)));
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en el sistema (Ls) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Cantidad de unidades en la cola (Lq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal resultado = (P * P) / (BigDecimal.One - P);
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "La cantidad de unidades en la cola (Lq) = " + resultado.ToString() + " [clientes]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en el sistema (Ws)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en el sistema (Ws) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Ls = lambda / ((BigDecimal.One - P) * (lambda + ((1 - P) * a)));
                            BigDecimal resultado = Ls / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en el sistema (Ws) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Tiempo en la cola (Wq)")
                    {
                        if (mu1 + mu2 == lambda)
                        {
                            lblResultado.Text = "El tiempo en la cola (Wq) = ∄";
                        }
                        else
                        {
                            BigDecimal P = lambda / (mu1 + mu2);
                            BigDecimal Lq = (P * P) / (BigDecimal.One - P);
                            BigDecimal resultado = Lq / lambda;
                            resultado = BigDecimal.Round(resultado, 5);
                            lblResultado.Text = "El tiempo en la cola (Wq) = " + resultado.ToString() + " [horas]";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de cero unidades en el sistema (Po)")
                    {
                        BigDecimal P = lambda / (mu1 + mu2);

                        if (1 - P + (lambda / a) == 0)
                        {
                            lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = ∄";
                        }
                        else
                        {
                            BigDecimal resultado = (BigDecimal.One - P) / (1 - P + (lambda / a));
                            BigDecimal resultadoPorcentual = resultado * 100;
                            resultado = BigDecimal.Round(resultado, 5);
                            resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                            lblResultado.Text = "La probabilidad de cero unidades en el sistema (Po) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                        }
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de n unidades en el sistema (Pn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }
                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal pFinal = BigDecimal.One;
                        for (int i = 0; i < n; i++)
                        {
                            pFinal *= pParcial;
                        }

                        BigDecimal resultado = (BigDecimal.One - n) * (pFinal);
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de n unidades en el sistema (Pn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de al menos n unidades en el sistema (Pan)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = (BigDecimal.One - pParcial) / (1 - pParcial + (lambda / a));
                        BigDecimal sumatoria = p0;

                        for (int i = 1; i < n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }
                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            sumatoria += pFinal;
                        }

                        BigDecimal resultado = BigDecimal.One - sumatoria;
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de al menos n unidades en el sistema (Pan) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Probabilidad de a lo sumo n unidades en el sistema (Psn)")
                    {
                        if (!int.TryParse(txtN.Text, out n))
                        {
                            MessageBox.Show("Ingrese el n correctamente");
                            return;
                        }

                        n = Convert.ToInt32(txtN.Text);
                        BigDecimal pParcial = lambda / (mu1 + mu2);
                        BigDecimal p0 = (BigDecimal.One - pParcial) / (1 - pParcial + (lambda / a));
                        BigDecimal resultado = p0;

                        for (int i = 1; i <= n; i++)
                        {
                            BigDecimal pFinal = BigDecimal.One;

                            for (int j = 0; j < i; j++)
                            {
                                pFinal *= pParcial;
                            }

                            pFinal = (BigDecimal.One - new BigDecimal(i)) * pFinal;
                            resultado += pFinal;
                        }
                        BigDecimal resultadoPorcentual = resultado * 100;
                        resultado = BigDecimal.Round(resultado, 5);
                        resultadoPorcentual = BigDecimal.Round(resultadoPorcentual, 2);
                        lblResultado.Text = "La probabilidad de a lo sumo n unidades en el sistema (Psn) = " + resultado.ToString() + " --> " + resultadoPorcentual.ToString() + " %";
                    }

                    if (cbTipoCalculo.Text == "Factor de uso crítico (Pc)")
                    {
                        BigDecimal r = mu2 / mu1;
                        BigDecimal resultado = 1 - (r * (1 + r) / 1 + (r * r));
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El factor de uso crítico (Pc) = " + resultado.ToString() + " [clientes / hora]";
                    }
                }

                if (cbTipoMM2.Text == "Sin interrupción de servicio")
                {
                    if (!ValidarDatos2())
                    {
                        return;
                    }

                    BigDecimal w0 = BigDecimal.Parse(txtLambda.Text);
                    BigDecimal q1 = BigDecimal.Parse(txtMu1.Text);
                    BigDecimal q2 = BigDecimal.Parse(txtMu2.Text);
                    BigDecimal ts1 = BigDecimal.Parse(txtTs1.Text);
                    BigDecimal ts2 = BigDecimal.Parse(txtTs2.Text);

                    if (cbTipoCalculo.Text == "Tiempo cliente Clase 1 en el sistema (Ws1)")
                    {
                        BigDecimal resultado = w0 + (q1 * ts1) + ts1;
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo que permanerá el cliente CLASE 1 en el sistema (Ws1) = " + resultado.ToString() + " [horas]";
                    }

                    if (cbTipoCalculo.Text == "Tiempo cliente Clase 1 en la cola (Wq1)")
                    {
                        BigDecimal resultado = w0 + (q1 * ts1);
                        resultado = BigDecimal.Round(resultado, 5);
                        lblResultado.Text = "El tiempo que permanerá el cliente CLASE 1 en en la cola (Wq1) = " + resultado.ToString() + " [horas]";
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error en la introducción de datos");
            }                                                                                                                    
        }
    }
}
