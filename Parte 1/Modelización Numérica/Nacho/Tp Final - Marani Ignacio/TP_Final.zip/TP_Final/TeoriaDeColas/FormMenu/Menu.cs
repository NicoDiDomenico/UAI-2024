using Vista;

namespace FormMenu
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnMM1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formMM1 = new MM1();
            formMM1.ShowDialog();
        }

        private void btnMM1N_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formMM1N = new MM1N();
            formMM1N.ShowDialog();
        }

        private void btnMM2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formMM2 = new MM2();
            formMM2.ShowDialog();
        }

        private void btnMG1_MD1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formMG1_MD1 = new MG1___MD1();
            formMG1_MD1.ShowDialog();
        }

        private void btnMM1Especiales_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formMM1Esp = new MM1_Especiales();
            formMM1Esp.ShowDialog();
        }
    }
}
